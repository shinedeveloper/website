package com.netsuite.tron;

import com.netsuite.tron.engine.Core;
import com.netsuite.tron.engine.ScreenManager;
import com.netsuite.tron.engine.structure.Color;
import com.netsuite.tron.engine.structure.KeyCode;
import com.netsuite.tron.engine.structure.Size;

import java.util.ArrayList;
import java.util.List;

import static com.netsuite.tron.PlayerDirection.LEFT;
import static com.netsuite.tron.PlayerDirection.RIGHT;

public class TronGame extends Core {

    private static final int DEFAULT_SPEED = 5;
    private final List<Player> players = new ArrayList<>();
    private final List<Controller> controllers = new ArrayList<>();

    public void init() {
        super.init();

        Player player1 = new Player(40, 40, RIGHT, Color.GREEN, DEFAULT_SPEED);
        Controller player1Controller = new KeyboardController(player1, KeyCode.VK_UP, KeyCode.VK_LEFT, KeyCode.VK_DOWN, KeyCode.VK_RIGHT);
        players.add(player1);
        controllers.add(player1Controller);

        Player player2 = new Player(600, 440, LEFT, Color.RED, DEFAULT_SPEED);
        Controller player2KeyboardController = new KeyboardController(player2, KeyCode.VK_W, KeyCode.VK_A, KeyCode.VK_S, KeyCode.VK_D);
        MouseController player2MouseController = new MouseController(player2);
        players.add(player2);
        controllers.add(player2KeyboardController);
        controllers.add(player2MouseController);
    }

    public static void main(String[] args) {
        new TronGame().run();
    }

    public void draw(ScreenManager sm) {
        sm.clearScreen();

        for (Player player : players) {
            player.draw(sm);
        }
    }

    @Override
    public void update(long timePassed) {
        super.update(timePassed);

        for (Controller controller : controllers) {
            controller.controlPlayer(sm);
        }

        Size screenSize = this.sm.getScreenSize();
        for (Player player : players) {
            player.move(screenSize);
        }

        for (Player player1 : players) {
            for (Player player2 : players) {
                if (player1.detectCollision(player2)) {
                    System.exit(0);
                }
            }
        }

        for (Player player : players) {
            player.addStep();
        }
    }
}
