package com.netsuite.tron;

public enum PlayerDirection {

    UP,
    LEFT,
    DOWN,
    RIGHT

}
