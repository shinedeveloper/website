package com.netsuite.tron;

import com.netsuite.tron.engine.ScreenManager;
import com.netsuite.tron.engine.structure.KeyCode;

import static com.netsuite.tron.PlayerDirection.DOWN;
import static com.netsuite.tron.PlayerDirection.LEFT;
import static com.netsuite.tron.PlayerDirection.RIGHT;
import static com.netsuite.tron.PlayerDirection.UP;

public class MouseController implements Controller {

    private final Player player;

    public MouseController(Player player) {
        this.player = player;
    }

    @Override
    public void controlPlayer(ScreenManager sm) {
        if (sm.isKeyPressed(KeyCode.MOUSE_KEY_CODE_BUTTON1)) {
            switch (player.getCurrentDirection()) {
                case UP:
                    player.setCurrentDirection(LEFT);
                    break;
                case LEFT:
                    player.setCurrentDirection(DOWN);
                    break;
                case DOWN:
                    player.setCurrentDirection(RIGHT);
                    break;
                case RIGHT:
                    player.setCurrentDirection(UP);
                    break;
            }
        }
        if (sm.isKeyPressed(KeyCode.MOUSE_KEY_CODE_BUTTON3)) {
            switch (player.getCurrentDirection()) {
                case UP:
                    player.setCurrentDirection(RIGHT);
                    break;
                case LEFT:
                    player.setCurrentDirection(UP);
                    break;
                case DOWN:
                    player.setCurrentDirection(LEFT);
                    break;
                case RIGHT:
                    player.setCurrentDirection(DOWN);
                    break;
            }
        }
    }
}
