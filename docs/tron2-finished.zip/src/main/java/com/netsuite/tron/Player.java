package com.netsuite.tron;

import com.netsuite.tron.engine.ScreenManager;
import com.netsuite.tron.engine.structure.Color;
import com.netsuite.tron.engine.structure.Size;

import java.util.ArrayList;
import java.util.List;

class Player {

    private final Color color;
    private final int speed;
    private CellPosition currentPos;
    private PlayerDirection currentDirection;
    private List<CellPosition> path = new ArrayList<>();

    Player(int startX, int startY, PlayerDirection currentDirection, Color color, int speed) {
        this.currentPos = new CellPosition(startX, startY);
        this.setCurrentDirection(currentDirection);
        this.color = color;
        this.speed = speed;
    }

    void move(Size screenSize) {
        int x = currentPos.getX();
        int y = currentPos.getY();
        switch (currentDirection) {
            case UP:
                y -= speed;
                break;
            case LEFT:
                x -= speed;
                break;
            case DOWN:
                y += speed;
                break;
            case RIGHT:
                x += speed;
                break;
        }

        x = clip(x, screenSize.getWidth());
        y = clip(y, screenSize.getHeight());

        currentPos = new CellPosition(x, y);
    }

    private int clip(int coord, int maxCoord) {
        if (coord >= maxCoord) {
            coord = 0;
        }
        if (coord < 0) {
            coord = maxCoord;
        }
        return coord;
    }

    PlayerDirection getCurrentDirection() {
        return currentDirection;
    }

    void setCurrentDirection(PlayerDirection currentDirection) {
        this.currentDirection = currentDirection;
    }

    boolean detectCollision(Player otherPlayer) {
        List<CellPosition> otherPath = otherPlayer.path;
        for (CellPosition otherPos : otherPath) {
            boolean isCollision = currentPos.equals(otherPos);
            if (isCollision) {
                return true;
            }
        }
        return false;
    }

    void addStep() {
        path.add(currentPos);
    }

    void draw(ScreenManager sm) {
        for (CellPosition cell : path) {
            sm.drawPlayerChunk(cell.getX(), cell.getY(), color);
        }
    }
}
