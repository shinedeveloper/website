package com.netsuite.tron.engine;

import java.util.concurrent.CancellationException;

public abstract class Core {

    private boolean running;
    protected ScreenManager sm;

    public void stop() {
        running = false;
    }

    public void run() {
        try {
            init();
            gameLoop();
        } finally {
            sm.restoreScreen();
        }
    }

    public void init() {
        sm = new TerminalScreenManager();
//        sm = new AwtScreenManager();
        sm.init();
        running = true;
    }

    public void gameLoop() {
        long startTime = System.currentTimeMillis();
        long cumTime = startTime;

        while (running) {
            long timePassed = System.currentTimeMillis() - cumTime;
            cumTime += timePassed;
            update(timePassed);
            draw(sm);
            sm.update();

            try {
                Thread.sleep(20L);
            } catch (InterruptedException ex) {
                throw new CancellationException();
            }
        }
    }

    public void update(long timePassed) {
		sm.testKeys();
    }

    public abstract void draw(ScreenManager sm);
}
