package com.netsuite.tron;

import com.netsuite.tron.engine.ScreenManager;
import com.netsuite.tron.engine.structure.KeyCode;

import static com.netsuite.tron.PlayerDirection.DOWN;
import static com.netsuite.tron.PlayerDirection.LEFT;
import static com.netsuite.tron.PlayerDirection.RIGHT;
import static com.netsuite.tron.PlayerDirection.UP;

public class KeyboardController implements Controller {

    private final KeyCode keyUp;
    private final KeyCode keyLeft;
    private final KeyCode keyDown;
    private final KeyCode keyRight;
    private final Player player;

    public KeyboardController(Player player, KeyCode keyUp, KeyCode keyLeft, KeyCode keyDown, KeyCode keyRight) {
        this.player = player;
        this.keyUp = keyUp;
        this.keyLeft = keyLeft;
        this.keyDown = keyDown;
        this.keyRight = keyRight;
    }

    public void controlPlayer(ScreenManager sm) {
        if (sm.isKeyPressed(keyUp)) {
            if (player.getCurrentDirection() != DOWN) {
                player.setCurrentDirection(UP);
            }
        } else if (sm.isKeyPressed(keyDown)) {
            if (player.getCurrentDirection() != UP) {
                player.setCurrentDirection(DOWN);
            }
        } else if (sm.isKeyPressed(keyRight)) {
            if (player.getCurrentDirection() != LEFT) {
                player.setCurrentDirection(RIGHT);
            }
        } else if (sm.isKeyPressed(keyLeft)) {
            if (player.getCurrentDirection() != RIGHT) {
                player.setCurrentDirection(LEFT);
            }
        }
    }
}