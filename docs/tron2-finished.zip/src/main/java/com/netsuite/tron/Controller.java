package com.netsuite.tron;

import com.netsuite.tron.engine.ScreenManager;

public interface Controller {
    void controlPlayer(ScreenManager sm);
}
