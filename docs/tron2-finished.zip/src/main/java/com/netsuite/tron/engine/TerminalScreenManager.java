package com.netsuite.tron.engine;

import com.googlecode.lanterna.TerminalSize;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;
import com.netsuite.tron.engine.structure.Color;
import com.netsuite.tron.engine.structure.KeyCode;
import com.netsuite.tron.engine.structure.Size;

import java.awt.*;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class TerminalScreenManager implements ScreenManager {

    public static final int X_FACTOR = 10;
    public static final int Y_FACTOR = 10;
    private Terminal terminal;
    private Set<KeyCode> keysDown = new HashSet<>();

    @Override
    public void init() {
        try {
            DefaultTerminalFactory factory = new DefaultTerminalFactory();
            factory.setInitialTerminalSize(new TerminalSize(200, 60));
            terminal = factory.createTerminal();
            terminal.setCursorVisible(false);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update() {
    }

    @Override
    public int getWidth() {
        throw new UnsupportedOperationException();
    }

    @Override
    public int getHeight() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Size getScreenSize() {
        try {
            return new Size(
                    terminal.getTerminalSize().getColumns() * X_FACTOR,
                    terminal.getTerminalSize().getRows() * Y_FACTOR);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void clearScreen() {
        
    }

    @Override
    public void drawPlayerChunk(int x, int y, Color color) {
        try {
            terminal.setCursorPosition(x / X_FACTOR, y / Y_FACTOR);

            if (color.getRed() > 100) {
                terminal.setBackgroundColor(TextColor.ANSI.RED);
                terminal.putCharacter('X');
            } else {
                terminal.setBackgroundColor(TextColor.ANSI.GREEN);
                terminal.putCharacter('O');
            }

            terminal.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void restoreScreen() {
        try {
            terminal.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void testKeys() {
        try {
            keysDown.clear();
            while (true) {
                KeyStroke keyStroke = terminal.pollInput();
                if (keyStroke == null) return;
                if (keyStroke.getKeyType() == KeyType.Character) {
                    Character pressedKey = keyStroke.getCharacter();
                    pressedKey = Character.toUpperCase(pressedKey);
                    keysDown.add(new KeyCode(pressedKey));
                } else if (keyStroke.getKeyType() == KeyType.ArrowUp) {
                    keysDown.add(KeyCode.VK_UP);
                } else if (keyStroke.getKeyType() == KeyType.ArrowLeft) {
                    keysDown.add(KeyCode.VK_LEFT);
                } else if (keyStroke.getKeyType() == KeyType.ArrowDown) {
                    keysDown.add(KeyCode.VK_DOWN);
                } else if (keyStroke.getKeyType() == KeyType.ArrowRight) {
                    keysDown.add(KeyCode.VK_RIGHT);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean isKeyPressed(KeyCode keyCode) {
        return keysDown.contains(keyCode);
    }
}
