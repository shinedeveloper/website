package com.netsuite.tron.engine.structure;

import java.util.Objects;

public class KeyCode {

    public static final KeyCode VK_UP = new KeyCode(38);
    public static final KeyCode VK_LEFT = new KeyCode(37);
    public static final KeyCode VK_DOWN = new KeyCode(40);
    public static final KeyCode VK_RIGHT = new KeyCode(39);
    public static final KeyCode VK_W = new KeyCode(87);
    public static final KeyCode VK_A = new KeyCode(65);
    public static final KeyCode VK_S = new KeyCode(83);
    public static final KeyCode VK_D = new KeyCode(68);
    public static final KeyCode MOUSE_KEY_CODE_BUTTON1 = new KeyCode(1_000_000);
    public static final KeyCode MOUSE_KEY_CODE_BUTTON2 = new KeyCode(1_000_001);
    public static final KeyCode MOUSE_KEY_CODE_BUTTON3 = new KeyCode(1_000_002);

    private int code;

    public KeyCode(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        KeyCode keyCode = (KeyCode) o;
        return code == keyCode.code;
    }

    @Override
    public int hashCode() {
        return Objects.hash(code);
    }
}
