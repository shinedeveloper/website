package com.netsuite.tron.engine;

import com.netsuite.tron.engine.structure.KeyCode;
import com.netsuite.tron.engine.structure.Size;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.DisplayMode;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Window;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;

public class AwtScreenManager implements ScreenManager {

    private static final DisplayMode modes[] = {
            //new DisplayMode(1920,1080,32,0),
            new DisplayMode(1680, 1050, 32, 0),
            //new DisplayMode(1280,1024,32,0),
            new DisplayMode(800, 600, 32, 0),
            new DisplayMode(800, 600, 24, 0),
            new DisplayMode(800, 600, 16, 0),
            new DisplayMode(640, 480, 32, 0),
            new DisplayMode(640, 480, 24, 0),
            new DisplayMode(640, 480, 16, 0),
    };

    private GraphicsDevice vc;
    private Set<KeyCode> pressedKeys = new HashSet<>();

    public AwtScreenManager() {
        GraphicsEnvironment e = GraphicsEnvironment.getLocalGraphicsEnvironment();
        vc = e.getDefaultScreenDevice();
    }

    @Override
    public void init() {
        DisplayMode dm = findFirstCompatibaleMode(modes);
        setFullScreen(dm);
        Window w = getFullScreenWindow();
        w.setFont(new Font("Arial", Font.PLAIN, 20));
        w.setBackground(Color.WHITE);
        w.setForeground(Color.RED);
        w.setCursor(w.getToolkit().createCustomCursor(new BufferedImage(3, 3, BufferedImage.TYPE_INT_ARGB), new Point(0, 0), "null"));

        w.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                pressedKeys.add(new KeyCode(e.getKeyCode()));
            }

            @Override
            public void keyReleased(KeyEvent e) {
                pressedKeys.remove(new KeyCode(e.getKeyCode()));
            }
        });
        w.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON1) {
                    pressedKeys.add(KeyCode.MOUSE_KEY_CODE_BUTTON1);
                }
                if (e.getButton() == MouseEvent.BUTTON2) {
                    pressedKeys.add(KeyCode.MOUSE_KEY_CODE_BUTTON2);
                }
                if (e.getButton() == MouseEvent.BUTTON3) {
                    pressedKeys.add(KeyCode.MOUSE_KEY_CODE_BUTTON3);
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (e.getButton() == MouseEvent.BUTTON1) {
                    pressedKeys.remove(KeyCode.MOUSE_KEY_CODE_BUTTON1);
                }
                if (e.getButton() == MouseEvent.BUTTON2) {
                    pressedKeys.remove(KeyCode.MOUSE_KEY_CODE_BUTTON2);
                }
                if (e.getButton() == MouseEvent.BUTTON3) {
                    pressedKeys.remove(KeyCode.MOUSE_KEY_CODE_BUTTON3);
                }
            }
        });
    }

    private DisplayMode findFirstCompatibaleMode(DisplayMode[] modes) {
        DisplayMode goodModes[] = vc.getDisplayModes();
        for (int x = 0; x < modes.length; x++) {
            for (int y = 0; y < goodModes.length; y++) {
                if (displayModesMatch(modes[x], goodModes[y])) {
                    return modes[x];
                }
            }
        }
        return null;
    }

    private boolean displayModesMatch(DisplayMode m1, DisplayMode m2) {
        if (m1.getWidth() != m2.getWidth() || m1.getHeight() != m2.getHeight()) {
            return false;
        }
        if (m1.getBitDepth() != DisplayMode.BIT_DEPTH_MULTI && m2.getBitDepth() != DisplayMode.BIT_DEPTH_MULTI && m1.getBitDepth() != m2.getBitDepth()) {
            return false;
        }
        if (m1.getRefreshRate() != DisplayMode.REFRESH_RATE_UNKNOWN && m2.getRefreshRate() != DisplayMode.REFRESH_RATE_UNKNOWN && m1.getRefreshRate() != m2.getRefreshRate()) {
            return false;
        }
        return true;
    }

    private void setFullScreen(DisplayMode dm) {
        JFrame f = new JFrame();
        f.setUndecorated(true);
        f.setIgnoreRepaint(true);
        f.setResizable(false);
        vc.setFullScreenWindow(f);

        if (dm != null && vc.isDisplayChangeSupported()) {
            try {
                vc.setDisplayMode(dm);
            } catch (Exception ex) {
            }
            f.createBufferStrategy(2);
        }
    }

    private Graphics2D getGraphics() {
        Window w = vc.getFullScreenWindow();
        if (w != null) {
            BufferStrategy bs = w.getBufferStrategy();
            if (bs == null) {
                w.createBufferStrategy(2);
                bs = w.getBufferStrategy();
            }
            return (Graphics2D) bs.getDrawGraphics();
        } else {
            return null;
        }
    }

    @Override
    public void update() {
        Window w = vc.getFullScreenWindow();
        if (w != null) {
            BufferStrategy bs = w.getBufferStrategy();
            if (!bs.contentsLost()) {
                bs.show();
            }
        }
    }

    private Window getFullScreenWindow() {
        return vc.getFullScreenWindow();
    }

    @Override
    public int getWidth() {
        Window w = vc.getFullScreenWindow();
        if (w != null) {
            return w.getWidth();
        } else {
            return 0;
        }
    }

    @Override
    public int getHeight() {
        Window w = vc.getFullScreenWindow();
        if (w != null) {
            return w.getHeight();
        } else {
            return 0;
        }
    }

    @Override
    public Size getScreenSize() {
        return new Size(getWidth(), getHeight());
    }

    @Override
    public void clearScreen() {
        Graphics2D g = getGraphics();
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        g.dispose();
    }

    @Override
    public void drawPlayerChunk(int x, int y, com.netsuite.tron.engine.structure.Color color) {
        Graphics2D g = getGraphics();
        g.setColor(translateToNative(color));
        g.fillRect(x, y, 10, 10);
        g.dispose();
    }

    private Color translateToNative(com.netsuite.tron.engine.structure.Color color) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue());
    }

    @Override
    public void restoreScreen() {
        Window w = vc.getFullScreenWindow();
        if (w != null) {
            w.dispose();
        }
        vc.setFullScreenWindow(null);
    }

    @Override
    public void testKeys() {
    }

    @Override
    public boolean isKeyPressed(KeyCode keyCode) {
        return pressedKeys.contains(keyCode);
    }
}
