package com.netsuite.tron.engine;

import com.netsuite.tron.engine.structure.KeyCode;
import com.netsuite.tron.engine.structure.Size;

public interface ScreenManager {

    void init();

    void update();

    int getWidth();

    int getHeight();

    Size getScreenSize();

    void clearScreen();

    void drawPlayerChunk(int x, int y, com.netsuite.tron.engine.structure.Color color);

    void restoreScreen();

    void testKeys();

    boolean isKeyPressed(KeyCode keyCode);
}
